'use strict';
// The Vercel runtime hands functions a req whose .body is already parsed (or a getter that throws on bad JSON).
const test = require('node:test');
const assert = require('node:assert');
const { wrap } = require('../lib/http');

function fakeRes() {
  const r = { statusCode: 0, headers: {}, body: null, setHeader(k, v) { this.headers[k.toLowerCase()] = v; }, end(b) { this.body = b ? JSON.parse(b) : null; } };
  return r;
}
const echo = async ctx => ({ status: 200, body: { got: ctx.body, ip: ctx.ip } });

test('pre-parsed req.body (Vercel) is used as-is; IP from x-forwarded-for', async () => {
  const res = fakeRes();
  await wrap(echo, { env: {} })({ method: 'POST', headers: { origin: 'https://www.hirewire.fyi', 'x-forwarded-for': '1.2.3.4, 10.0.0.1' }, body: { plan: '7d' } }, res);
  assert.strictEqual(res.statusCode, 200);
  assert.deepStrictEqual(res.body.got, { plan: '7d' });
  assert.strictEqual(res.body.ip, '1.2.3.4');
  assert.strictEqual(res.headers['access-control-allow-origin'], 'https://www.hirewire.fyi');
  assert.strictEqual(res.headers['cache-control'], 'no-store');
});
test('req.body getter that throws (invalid JSON on Vercel) → 400 bad_json', async () => {
  const res = fakeRes();
  const req = { method: 'POST', headers: { origin: 'https://hirewire.fyi' } };
  Object.defineProperty(req, 'body', { get() { throw new Error('Invalid JSON'); } });
  await wrap(echo, { env: {} })(req, res);
  assert.strictEqual(res.statusCode, 400); assert.strictEqual(res.body.error, 'bad_json');
});
test('oversized pre-parsed body → 413', async () => {
  const res = fakeRes();
  await wrap(echo, { env: {} })({ method: 'POST', headers: { origin: 'https://hirewire.fyi' }, body: { cv: 'x'.repeat(300000) } }, res);
  assert.strictEqual(res.statusCode, 413);
});
test('ALLOWED_ORIGINS adds extra origins', async () => {
  const res = fakeRes();
  await wrap(echo, { env: { ALLOWED_ORIGINS: 'https://staging.hirewire.fyi' } })({ method: 'POST', headers: { origin: 'https://staging.hirewire.fyi' }, body: {} }, res);
  assert.strictEqual(res.statusCode, 200);
});
