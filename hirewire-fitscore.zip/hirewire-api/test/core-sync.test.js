'use strict';
// The browser (BYOK) path must use the exact same prompt/schema/validator as the server.
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const path = require('path');
const html = path.join(__dirname, '..', '..', 'repo', 'index.html');

test('index.html embeds lib/core.js verbatim', { skip: !fs.existsSync(html) && 'repo/index.html not found' }, () => {
  const src = fs.readFileSync(path.join(__dirname, '..', 'lib', 'core.js'), 'utf8').trimEnd();
  const page = fs.readFileSync(html, 'utf8');
  const B = '/* FITSCORE-CORE:BEGIN — generated from hirewire-api/lib/core.js; do not edit here */\n';
  const E = '\n/* FITSCORE-CORE:END */';
  const i = page.indexOf(B), j = page.indexOf(E);
  assert.ok(i >= 0 && j > i, 'markers present');
  assert.strictEqual(page.slice(i + B.length, j), src, 'run: npm run sync-core');
});
