'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { signPass, verifyPass, b64url, fromB64url } = require('../lib/token');
const SECRET = 'x'.repeat(40);

test('sign → verify round trip', () => {
  const exp = Date.now() + 7 * 864e5;
  const t = signPass({ plan: '7d', sid: 'cs_test_abc123456789', exp }, SECRET);
  assert.match(t, /^hw1\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/);
  const v = verifyPass(t, SECRET);
  assert.strictEqual(v.ok, true);
  assert.strictEqual(v.payload.plan, '7d');
  assert.strictEqual(v.payload.exp, exp);
});
test('expired token is rejected with reason expired', () => {
  const t = signPass({ plan: '30d', sid: 'cs_test_abc123456789', exp: Date.now() - 1 }, SECRET);
  const v = verifyPass(t, SECRET);
  assert.strictEqual(v.ok, false); assert.strictEqual(v.reason, 'expired');
});
test('wrong secret → bad_signature', () => {
  const t = signPass({ plan: '7d', sid: 'cs_test_abc123456789', exp: Date.now() + 1e6 }, SECRET);
  assert.strictEqual(verifyPass(t, 'y'.repeat(40)).reason, 'bad_signature');
});
test('tampered payload (extended exp) → bad_signature', () => {
  const t = signPass({ plan: '7d', sid: 'cs_test_abc123456789', exp: Date.now() + 1e6 }, SECRET);
  const [p, body, sig] = t.split('.');
  const obj = JSON.parse(fromB64url(body).toString());
  obj.exp += 30 * 864e5; obj.plan = '30d';
  const forged = [p, b64url(JSON.stringify(obj)), sig].join('.');
  assert.strictEqual(verifyPass(forged, SECRET).reason, 'bad_signature');
});
test('malformed inputs', () => {
  for (const t of [null, '', 'abc', 'hw1..', 'hw2.a.b', 'hw1.a.b.c', 'x'.repeat(2000)]) {
    assert.strictEqual(verifyPass(t, SECRET).ok, false);
  }
});
test('short secret throws a config error', () => {
  assert.throws(() => signPass({ plan: '7d', sid: 's', exp: 1 }, 'short'), /PASS_SECRET/);
});
