'use strict';
// End-to-end over real HTTP: local API (same adapter as Vercel) → mocked Anthropic / Stripe / Upstash.
const test = require('node:test');
const assert = require('node:assert');
const { startMockStack } = require('../dev/local-server');
const { payMockSession } = require('../dev/mocks');
const { signPass } = require('../lib/token');

const ORIGIN = 'https://hirewire.fyi';
const CV = 'Backend engineer with 5 years of TypeScript and Node.js. Improved Postgres query performance for the billing service. Built the Apollo API layer for the mobile app. Mentored one intern. Deployed services on AWS ECS. '.repeat(2);
const JOB = { title: 'Senior Backend Engineer', company: 'Acme', description: 'You will own TypeScript/Node services on Kubernetes, design GraphQL APIs, tune PostgreSQL, and lead a team of 4 engineers. Terraform a plus.' };

async function call(base, path, body, opts) {
  opts = opts || {};
  const headers = { 'content-type': 'application/json' };
  if (opts.origin !== null) headers.origin = opts.origin || ORIGIN;
  if (opts.ip) headers['x-forwarded-for'] = opts.ip;
  const r = await fetch(base + path, { method: opts.method || 'POST', headers, body: body === undefined ? undefined : (typeof body === 'string' ? body : JSON.stringify(body)) });
  let data = null; const t = await r.text(); try { data = t ? JSON.parse(t) : null; } catch (e) { data = t; }
  return { status: r.status, data, headers: r.headers };
}

test('API end-to-end with mocked upstreams', async (t) => {
  const S = await startMockStack();
  const { base } = S.api; const ctl = S.mocks.ctl;
  const logs = []; const origErr = console.error; console.error = (...a) => logs.push(a.join(' '));
  t.after(async () => { console.error = origErr; await S.close(); });

  await t.test('CORS: preflight allowed for hirewire.fyi, www and localhost; denied for others', async () => {
    for (const o of ['https://hirewire.fyi', 'https://www.hirewire.fyi', 'http://localhost:8080', 'http://127.0.0.1:5500']) {
      const r = await fetch(base + '/api/score', { method: 'OPTIONS', headers: { origin: o, 'access-control-request-method': 'POST' } });
      assert.strictEqual(r.status, 204, o);
      assert.strictEqual(r.headers.get('access-control-allow-origin'), o);
    }
    const bad = await fetch(base + '/api/score', { method: 'OPTIONS', headers: { origin: 'https://evil.example' } });
    assert.strictEqual(bad.status, 403);
    assert.strictEqual(bad.headers.get('access-control-allow-origin'), null);
    const r = await call(base, '/api/score', { cv: CV, job: JOB }, { origin: 'https://evil.example' });
    assert.strictEqual(r.status, 403);
    const r2 = await call(base, '/api/score', { cv: CV, job: JOB }, { origin: null });
    assert.strictEqual(r2.status, 403);
  });

  await t.test('health reports booleans only', async () => {
    const r = await call(base, '/api/health', undefined, { method: 'GET', origin: null });
    assert.strictEqual(r.status, 200);
    assert.strictEqual(r.data.anthropic, true);
    assert.ok(!JSON.stringify(r.data).includes('sk-'));
  });

  await t.test('free score happy path: validated result, upstream request shape, remaining count', async () => {
    const r = await call(base, '/api/score', { cv: CV, job: JOB }, { ip: '10.0.0.1' });
    assert.strictEqual(r.status, 200, JSON.stringify(r.data));
    assert.strictEqual(r.data.mode, 'free');
    assert.strictEqual(r.data.result.fixes[0].rank, 1);
    assert.strictEqual(r.data.free_remaining_today, 4);
    const last = ctl.last.anthropic;
    assert.strictEqual(last.headers['x-api-key'], 'sk-ant-mock');
    assert.strictEqual(last.headers['anthropic-version'], '2023-06-01');
    assert.strictEqual(last.body.model, 'claude-haiku-5-5');
    assert.strictEqual(last.body.output_config.format.type, 'json_schema');
    assert.strictEqual(last.body.output_config.effort, 'low');
    assert.ok(last.body.messages[0].content.includes('<cv>'));
    // raw IPs are never used as keys
    assert.ok(Object.keys(ctl.counters).every(k => !k.includes('10.0.0.1')));
  });

  await t.test('per-IP free limit: 5/day then 429 free_limit_ip; other IPs unaffected', async () => {
    for (let i = 0; i < 4; i++) assert.strictEqual((await call(base, '/api/score', { cv: CV, job: JOB }, { ip: '10.0.0.1' })).status, 200);
    const r = await call(base, '/api/score', { cv: CV, job: JOB }, { ip: '10.0.0.1' });
    assert.strictEqual(r.status, 429); assert.strictEqual(r.data.error, 'free_limit_ip');
    assert.strictEqual((await call(base, '/api/score', { cv: CV, job: JOB }, { ip: '10.0.0.2' })).status, 200);
  });

  await t.test('input validation and size limits', async () => {
    assert.strictEqual((await call(base, '/api/score', '{bad json')).status, 400);
    assert.strictEqual((await call(base, '/api/score', { job: JOB })).data.error, 'missing_fields');
    assert.strictEqual((await call(base, '/api/score', { cv: 'too short', job: JOB })).data.error, 'cv_too_short');
    const big = await call(base, '/api/score', { cv: 'a'.repeat(20001), job: JOB });
    assert.strictEqual(big.status, 413); assert.strictEqual(big.data.error, 'cv_too_long');
    const bigJd = await call(base, '/api/score', { cv: CV, job: Object.assign({}, JOB, { description: 'b'.repeat(20001) }) });
    assert.strictEqual(bigJd.status, 413); assert.strictEqual(bigJd.data.error, 'jd_too_long');
    const huge = await call(base, '/api/score', { cv: 'c'.repeat(300000), job: JOB });
    assert.strictEqual(huge.status, 413);
    assert.strictEqual((await call(base, '/api/score', { cv: CV, job: JOB }, { method: 'PUT' })).status, 405);
  });

  await t.test('upstream failures map to clean errors and do not burn the IP allowance', async () => {
    const ip = '10.0.0.9';
    for (const [mode, code, status] of [['busy', 'upstream_busy', 503], ['error', 'upstream_error', 502], ['invalid_json', 'model_output_invalid', 502], ['bad_schema', 'model_output_invalid', 502], ['refusal', 'model_refused', 502]]) {
      ctl.anthropic = mode;
      const r = await call(base, '/api/score', { cv: CV, job: JOB }, { ip });
      assert.strictEqual(r.status, status, mode); assert.strictEqual(r.data.error, code, mode);
    }
    ctl.anthropic = 'ok';
    const r = await call(base, '/api/score', { cv: CV, job: JOB }, { ip });
    assert.strictEqual(r.data.free_remaining_today, 4, 'failed calls were refunded');
  });

  let sessionId, token;
  await t.test('checkout: creates a one-time EUR session with the right price, metadata and return URLs', async () => {
    const bad = await call(base, '/api/checkout', { plan: '90d' });
    assert.strictEqual(bad.status, 400);
    const r = await call(base, '/api/checkout', { plan: '7d' });
    assert.strictEqual(r.status, 200);
    assert.match(r.data.url, /^https:\/\/checkout\.stripe\.com\//);
    sessionId = r.data.id;
    const p = ctl.last.stripeCreate.params;
    assert.strictEqual(ctl.last.stripeCreate.auth, 'Bearer sk_test_mock');
    assert.strictEqual(p.mode, 'payment');
    assert.strictEqual(p['line_items[0][price]'], 'price_7d_mock');
    assert.strictEqual(p['metadata[plan]'], '7d');
    assert.strictEqual(p['metadata[app]'], 'hirewire-fitscore');
    assert.strictEqual(p.success_url, 'http://localhost:8080/?pass_session={CHECKOUT_SESSION_ID}');
    assert.strictEqual(p.cancel_url, 'http://localhost:8080/?pass_cancel=1');
    const r30 = await call(base, '/api/checkout', { plan: '30d' });
    assert.strictEqual(ctl.last.stripeCreate.params['line_items[0][price]'], 'price_30d_mock');
    assert.ok(r30.data.id);
  });

  await t.test('checkout: Stripe error → 502 stripe_error', async () => {
    ctl.stripeCreate = 'error';
    const r = await call(base, '/api/checkout', { plan: '30d' });
    assert.strictEqual(r.status, 502); assert.strictEqual(r.data.error, 'stripe_error');
    ctl.stripeCreate = 'ok';
  });

  await t.test('claim: unpaid → 402, paid → signed token; re-claim works; pasted URL accepted', async () => {
    let r = await call(base, '/api/claim', { session_id: sessionId });
    assert.strictEqual(r.status, 402); assert.strictEqual(r.data.error, 'not_paid');
    payMockSession(ctl, sessionId);
    r = await call(base, '/api/claim', { session_id: sessionId });
    assert.strictEqual(r.status, 200);
    assert.strictEqual(r.data.plan, '7d');
    const days = (r.data.exp - Date.now()) / 864e5;
    assert.ok(days > 6.9 && days <= 7, 'exp ~7 days from payment');
    token = r.data.token;
    const again = await call(base, '/api/claim', { session_id: 'https://hirewire.fyi/?pass_session=' + sessionId });
    assert.strictEqual(again.status, 200);
    assert.strictEqual(again.data.exp, r.data.exp, 're-claim does not extend the pass');
  });

  await t.test('claim errors: bad id, unknown session, foreign product, expired', async () => {
    assert.strictEqual((await call(base, '/api/claim', { session_id: 'nope' })).data.error, 'bad_session_id');
    assert.strictEqual((await call(base, '/api/claim', { session_id: 'cs_test_doesnotexist000' })).status, 404);
    ctl.stripeSession.cs_test_otherproduct01 = { id: 'cs_test_otherproduct01', status: 'complete', payment_status: 'paid', created: Math.floor(Date.now() / 1000), metadata: {} };
    assert.strictEqual((await call(base, '/api/claim', { session_id: 'cs_test_otherproduct01' })).data.error, 'not_a_hirewire_pass');
    ctl.stripeSession.cs_test_oldpass0000001 = { id: 'cs_test_oldpass0000001', status: 'complete', payment_status: 'paid', created: Math.floor(Date.now() / 1000) - 8 * 86400, metadata: { app: 'hirewire-fitscore', plan: '7d' } };
    const r = await call(base, '/api/claim', { session_id: 'cs_test_oldpass0000001' });
    assert.strictEqual(r.status, 410); assert.strictEqual(r.data.error, 'pass_expired');
  });

  await t.test('pass score: token accepted, bypasses the IP limit; forged/expired tokens rejected', async () => {
    const r = await call(base, '/api/score', { cv: CV, job: JOB, token }, { ip: '10.0.0.1' });   // this IP is over its free limit
    assert.strictEqual(r.status, 200, JSON.stringify(r.data));
    assert.strictEqual(r.data.mode, 'pass');
    const forged = token.slice(0, -3) + (token.endsWith('AAA') ? 'BBB' : 'AAA');
    assert.strictEqual((await call(base, '/api/score', { cv: CV, job: JOB, token: forged })).data.error, 'invalid_token');
    const expired = signPass({ plan: '7d', sid: sessionId, exp: Date.now() - 1000 }, S.env.PASS_SECRET);
    const e = await call(base, '/api/score', { cv: CV, job: JOB, token: expired });
    assert.strictEqual(e.status, 402); assert.strictEqual(e.data.error, 'pass_expired');
  });

  await t.test('privacy: no CV text ever reaches the logs', async () => {
    const joined = logs.join('\n');
    assert.ok(!joined.includes('Postgres query performance'), 'CV text leaked into logs');
    assert.ok(!joined.includes('Kubernetes'), 'JD text leaked into logs');
  });
});

test('without Upstash the IP limit is skipped (fail-open by design) and kill switch works', async (t) => {
  const S = await startMockStack({ UPSTASH_REDIS_REST_URL: '', UPSTASH_REDIS_REST_TOKEN: '' });
  t.after(() => S.close());
  for (let i = 0; i < 7; i++) {
    const r = await call(S.api.base, '/api/score', { cv: CV, job: JOB }, { ip: '10.1.1.1' });
    assert.strictEqual(r.status, 200);
    assert.strictEqual(r.data.free_remaining_today, null);
  }
  const S2 = await startMockStack({ FREE_SCORES_ENABLED: '0' });
  t.after(() => S2.close());
  const r = await call(S2.api.base, '/api/score', { cv: CV, job: JOB });
  assert.strictEqual(r.status, 402); assert.strictEqual(r.data.error, 'free_disabled');
});

test('optional terms consent is passed to Stripe Checkout', async (t) => {
  const S = await startMockStack({ STRIPE_REQUIRE_TERMS: '1', STRIPE_TERMS_MESSAGE: 'I agree to the [Terms](https://hirewire.fyi/terms.html).' });
  t.after(() => S.close());
  const r = await call(S.api.base, '/api/checkout', { plan: '7d' });
  assert.strictEqual(r.status, 200);
  const p = S.mocks.ctl.last.stripeCreate.params;
  assert.strictEqual(p['consent_collection[terms_of_service]'], 'required');
  assert.match(p['custom_text[terms_of_service_acceptance][message]'], /Terms/);
});

test('missing config gives 503 with a clear code', async (t) => {
  const S = await startMockStack({ ANTHROPIC_API_KEY: '', STRIPE_PRICE_30D: '', PASS_SECRET: 'short' });
  t.after(() => S.close());
  assert.strictEqual((await call(S.api.base, '/api/score', { cv: CV, job: JOB })).data.error, 'config_anthropic_key');
  assert.strictEqual((await call(S.api.base, '/api/checkout', { plan: '30d' })).data.error, 'config_stripe_price');
  assert.strictEqual((await call(S.api.base, '/api/claim', { session_id: 'cs_test_abcdefghijkl' })).data.error, 'config_pass_secret');
});
