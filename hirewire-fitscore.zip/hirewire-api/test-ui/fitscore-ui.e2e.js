// Headless end-to-end test of the AI Fit Score UI in repo/index.html.
// The page runs in jsdom; its fetch() is routed to the REAL hirewire-api handlers (dev/local-server.js),
// which talk to mocked Anthropic/Stripe/Upstash. BYOK calls to api.anthropic.com go to the same mock.
// Run: npm i --no-save jsdom@24 && node test-ui/fitscore-ui.e2e.js   (not part of npm test: needs jsdom)
const path = require('path');
const fs = require('fs');
const assert = require('assert');
const { JSDOM, VirtualConsole } = require('jsdom');
const API = path.join(__dirname, '..');
const { startMockStack } = require(path.join(API, 'dev', 'local-server'));
const { payMockSession } = require(path.join(API, 'dev', 'mocks'));
const { signPass } = require(path.join(API, 'lib', 'token'));
const HTML = path.join(__dirname, '..', '..', 'repo', 'index.html');

const CV = `Pat Example — Backend Engineer
Backend engineer with 5 years of TypeScript and Node.js.
- Improved Postgres query performance for the billing service.
- Built the Apollo API layer for the mobile app.
- Deployed services on AWS ECS with GitHub Actions.
- Mentored one intern.
Education: BSc Computer Science.`;

const sleep = ms => new Promise(r => setTimeout(r, ms));
async function until(fn, ms, label){
  const t0 = Date.now();
  while (Date.now() - t0 < (ms || 5000)){ try { const v = fn(); if (v) return v; } catch(e){} await sleep(25); }
  throw new Error('timeout waiting for ' + (label || fn.toString().slice(0, 80)));
}
const results = [];
function check(name, cond, extra){ results.push((cond ? 'PASS ' : 'FAIL ') + name + (extra && !cond ? ' — ' + extra : '')); if (!cond) process.exitCode = 1; }

(async () => {
  const S = await startMockStack({ PUBLIC_SITE_URL: 'https://hirewire.fyi' });
  const ctl = S.mocks.ctl;
  const html = fs.readFileSync(HTML, 'utf8');
  check('API_BASE constant present and easy to change', /const API_BASE = 'https:\/\/hirewire-api\.vercel\.app';/.test(html));
  const errors = [];
  const vc = new VirtualConsole();
  vc.on('error', (...a) => errors.push('console.error: ' + a.join(' ')));
  vc.on('jsdomError', e => { if (!/Not implemented: navigation/.test(e.message)) errors.push('jsdomError: ' + (e.message || e)); });
  const seen = { api: [], anthropic: [], scoreBodies: [] };
  const dom = new JSDOM(html, {
    url: 'https://hirewire.fyi/', runScripts: 'dangerously', pretendToBeVisual: true, virtualConsole: vc,
    beforeParse(w){
      w.fetch = async (url, opt) => {
        opt = Object.assign({}, opt || {}); delete opt.signal;   // jsdom AbortSignal ≠ Node's
        if (url.startsWith('https://hirewire-api.vercel.app/')){
          seen.api.push(url.replace('https://hirewire-api.vercel.app', ''));
          if (url.endsWith('/api/score')) seen.scoreBodies.push(JSON.parse(opt.body));
          opt.headers = Object.assign({}, opt.headers, { origin: 'https://hirewire.fyi' });   // what the browser would send
          return fetch(S.api.base + url.replace('https://hirewire-api.vercel.app', ''), opt);
        }
        if (url === 'https://api.anthropic.com/v1/messages'){
          seen.anthropic.push(opt.headers);
          return fetch(S.mocks.base + '/v1/messages', opt);
        }
        throw new TypeError('Failed to fetch');   // job feeds: offline
      };
      w.URL.createObjectURL = () => 'blob:x'; w.URL.revokeObjectURL = () => {};
      w.confirm = () => true;
      w.navigator.clipboard = { writeText: async t => { w.__clip = t; } };
    }
  });
  const w = dom.window, d = w.document;
  const $ = s => d.querySelector(s);
  const toasts = () => Array.from(d.querySelectorAll('#toasts .toast')).map(t => t.textContent).join(' | ');
  let navigated = null;
  w.fsNavigate = url => { navigated = url; };
  await sleep(1500);

  check('no boot error bar', $('#errbar').hidden, $('#errbar').textContent);
  check('core loaded in page (HWFitCore)', w.eval('typeof HWFitCore === "object" && HWFitCore.DEFAULT_MODEL') === 'claude-haiku-5-5');
  check('sidebar status shows 3 of 3 free', /3 OF 3 FREE SCORES LEFT/.test($('#fsStatus').textContent), $('#fsStatus').textContent);

  // load the 10 sample postings
  const sb = $('#sampleBar [data-act="sample"]') || $('#wire [data-act="sample"]');
  sb.click(); await sleep(100);
  const ids = Array.from(d.querySelectorAll('#wire .row')).map(r => r.dataset.id).filter(x => x.startsWith('sample:'));
  check('sample jobs loaded', ids.length >= 6, String(ids.length));
  check('rows have an AI FIT action', !!d.querySelector('#wire .row [data-act="fsrow"]'));

  // 1) open drawer: no CV yet → paste box
  d.querySelector('#wire .row[data-id="' + ids[0] + '"]').click(); await sleep(50);
  check('drawer has AI fit score box', !!$('#fsBox'));
  check('box asks for CV (textarea + remember checkbox)', !!$('#fsCv') && !!$('#fsRemember'));
  check('privacy line shown before sending', /not store or log/i.test($('#fsBox').textContent));
  $('#fsBox [data-act="fsrun"]').click(); await sleep(50);
  check('scoring without CV shows need-CV error and calls nothing', /Paste your CV/.test($('#fsBox .fs-err').textContent) && ctl.calls.anthropic === 0);

  // 2) paste CV → free score #1
  $('#fsCv').value = CV;
  $('#fsBox [data-act="fsrun"]').click();
  await until(() => $('#fsBox .fs-score'), 5000, 'result');
  check('result renders score 6.5/10', $('#fsBox .fs-score b').textContent === '6.5');
  check('projected score line', /PROJECTED 8\/10/.test($('#fsBox .fs-projline').textContent), $('#fsBox .fs-projline').textContent);
  const fixes = d.querySelectorAll('#fsBox .fs-fix');
  check('4 ranked fixes, GraphQL first (sorted by rank)', fixes.length === 4 && /GraphQL/.test(fixes[0].textContent));
  check('real vs wording gap labels', d.querySelectorAll('#fsBox .gap-real').length === 2 && d.querySelectorAll('#fsBox .gap-word').length === 2);
  check('rewrites have copy buttons; placeholder warning shown', d.querySelectorAll('#fsBox [data-act="fscopy"]').length === 2 && !!$('#fsBox .fs-ph'));
  check('evidence quotes are grounded in the CV (no unverified flag)', !$('#fsBox .fs-unv'));
  check('missing keywords rendered as gap chips', d.querySelectorAll('#fsBox .kw.gap').length === 3);
  d.querySelector('#fsBox [data-act="fscopy"]').click(); await sleep(30);
  check('copy rewrite → clipboard', /GraphQL \(Apollo\)/.test(w.__clip || ''));
  const ai1 = JSON.parse(w.localStorage.getItem('hirewire.ai.v1'));
  check('free counter 1 and CV kept (opt-in checkbox)', ai1.freeUsed === 1 && ai1.cv.includes('Apollo'));
  const fit1 = JSON.parse(w.localStorage.getItem('hirewire.fitscore.v1'));
  check('result cached per job in localStorage', fit1[ids[0]] && fit1[ids[0]].result.score === 6.5 && fit1[ids[0]].mode === 'free');
  check('server request carried CV + posting in tags, model haiku 5.5', ctl.last.anthropic.body.model === 'claude-haiku-5-5' && /<cv>[\s\S]*Apollo/.test(ctl.last.anthropic.body.messages[0].content));
  check('free-mode request carries no pass token, only cv + job', !('token' in seen.scoreBodies[0]) && Object.keys(seen.scoreBodies[0]).sort().join() === 'cv,job');
  w.eval('closeDrawer()'); await sleep(20);
  check('wire row shows cached AI badge', /AI 6\.5\/10/.test(d.querySelector('#wire .row[data-id="' + ids[0] + '"]').textContent));

  // reopening uses the cache (no new upstream call)
  const callsBefore = ctl.calls.anthropic;
  d.querySelector('#wire .row[data-id="' + ids[0] + '"]').click(); await sleep(50);
  check('reopen shows cached result without a new call', $('#fsBox .fs-score') && ctl.calls.anthropic === callsBefore);
  w.eval('closeDrawer()');

  // 3) free #2 and #3 via the row action
  for (const id of [ids[1], ids[2]]){
    d.querySelector('#wire .row[data-id="' + id + '"] [data-act="fsrow"]').click();
    await until(() => w.eval('!!state.fit[' + JSON.stringify(id) + ']') && !w.eval('state.fsBusy[' + JSON.stringify(id) + ']'), 5000, 'row score ' + id);
    w.eval('closeDrawer()');
  }
  check('3 free scores used', JSON.parse(w.localStorage.getItem('hirewire.ai.v1')).freeUsed === 3);
  check('sidebar says free used', /FREE SCORES USED/.test($('#fsStatus').textContent), $('#fsStatus').textContent);

  // 4) 4th → paywall, no upstream call
  const c4 = ctl.calls.anthropic;
  d.querySelector('#wire .row[data-id="' + ids[3] + '"]').click(); await sleep(30);
  $('#fsBox [data-act="fsrun"]').click(); await sleep(50);
  check('paywall opens after 3 free scores', $('#fsModal').classList.contains('open') && /USED YOUR 3 FREE/.test($('#fsModal').textContent));
  check('paywall shows both passes + BYOK + restore', /€9/.test($('#fsModal').textContent) && /€19/.test($('#fsModal').textContent) && !!$('#fsKey') && !!$('#fsRestoreId'));
  check('no upstream call when locked', ctl.calls.anthropic === c4);

  // 5) buy 30-day pass → Stripe Checkout URL
  $('#fsModal [data-act="fsbuy"][data-plan="30d"]').click();
  await until(() => navigated, 4000, 'navigate');
  check('checkout redirects to Stripe', /^https:\/\/checkout\.stripe\.com\//.test(navigated), navigated);
  check('checkout used the 30d price + success URL', ctl.last.stripeCreate.params['line_items[0][price]'] === 'price_30d_mock' &&
    ctl.last.stripeCreate.params.success_url === 'https://hirewire.fyi/?pass_session={CHECKOUT_SESSION_ID}');
  const sid = navigated.split('/').pop();

  // 6) customer pays; Stripe sends them back to /?pass_session=…
  payMockSession(ctl, sid);
  w.eval('closeFsModal(); closeDrawer()');
  w.history.replaceState(null, '', '/?pass_session=' + sid + '#top');
  w.eval('fsHandleReturn()');
  await until(() => w.eval('!!(state.ai.pass && state.ai.pass.token)'), 4000, 'claim');
  check('pass claimed and stored', JSON.parse(w.localStorage.getItem('hirewire.ai.v1')).pass.plan === '30d');
  check('return URL cleaned (no session id left in the address bar)', w.location.search === '' && w.location.hash === '#top', w.location.href);
  check('claimed modal shows expiry + pass ID with copy', $('#fsModal').classList.contains('open') && $('#fsModal').textContent.includes(sid) && !!$('#fsModal [data-act="fscopyid"]'));
  const days = (w.eval('state.ai.pass.exp') - Date.now()) / 864e5;
  check('30-day expiry', days > 29.9 && days <= 30, String(days));
  check('sidebar shows pass active', /JOB SEARCH PASS ACTIVE UNTIL/.test($('#fsStatus').textContent));
  w.eval('closeFsModal()');

  // 7) pass score
  d.querySelector('#wire .row[data-id="' + ids[3] + '"]').click(); await sleep(30);
  check('drawer chip shows pass active', /PASS ACTIVE/.test($('#fsBox .fs-mode').textContent));
  $('#fsBox [data-act="fsrun"]').click();
  await until(() => $('#fsBox .fs-score'), 5000, 'pass result');
  check('pass-mode request carries the signed token', /^hw1\./.test(seen.scoreBodies[seen.scoreBodies.length - 1].token || ''));
  check('pass mode result cached as pass', w.eval('state.fit[' + JSON.stringify(ids[3]) + '].mode') === 'pass');
  check('free counter unchanged by pass use', w.eval('state.ai.freeUsed') === 3);
  w.eval('closeDrawer()');

  // 8) restore on "another device": wipe the pass, restore from the pass ID
  w.eval('state.ai.pass = null; saveAi(); renderFsStatus()');
  $('#fsManageBtn').click(); await sleep(20);
  $('#fsRestoreId').value = 'https://hirewire.fyi/?pass_session=' + sid;
  $('#fsModal [data-act="fsrestore"]').click();
  await until(() => w.eval('!!state.ai.pass'), 4000, 'restore');
  check('restore from pasted return link works, same expiry', Math.abs(w.eval('state.ai.pass.exp') - (Date.now() + 30 * 864e5)) < 120000);
  $('#fsRestoreId') && ($('#fsRestoreId').value = 'nonsense');
  $('#fsModal [data-act="fsrestore"]').click(); await sleep(50);
  check('bad pass ID → friendly toast', /DOESN.T LOOK LIKE A PASS ID/.test(toasts()));
  w.eval('closeFsModal()');

  // 9) expired pass token → 402 → paywall with pass_expired
  const expired = signPass({ plan: '7d', sid, exp: Date.now() - 1000 }, S.env.PASS_SECRET);
  w.eval('state.ai.pass = { token:' + JSON.stringify(expired) + ', plan:"7d", exp:Date.now() + 864e5, sid:' + JSON.stringify(sid) + ' }');
  d.querySelector('#wire .row[data-id="' + ids[4] + '"]').click(); await sleep(30);
  $('#fsBox [data-act="fsrun"]').click();
  await until(() => $('#fsModal').classList.contains('open'), 4000, 'expired modal');
  check('server-side expiry is enforced → paywall "pass expired"', /PASS HAS EXPIRED/.test($('#fsModal').textContent));
  check('expired pass no longer active locally', w.eval('fsMode()') === 'locked');
  w.eval('closeFsModal(); closeDrawer()');

  // 10) BYOK: bad key rejected; good key → browser calls Anthropic directly with the browser-access header
  $('#fsManageBtn').click(); await sleep(20);
  $('#fsKey').value = 'not-a-key'; $('#fsModal [data-act="fskeysave"]').click(); await sleep(20);
  check('invalid key format rejected', /DOESN.T LOOK LIKE AN ANTHROPIC KEY/.test(toasts()) && !w.eval('state.ai.byokKey'));
  const KEY = 'sk-ant-api03-' + 'x'.repeat(40);
  $('#fsKey').value = KEY; $('#fsModal [data-act="fskeysave"]').click(); await sleep(20);
  check('key saved locally', JSON.parse(w.localStorage.getItem('hirewire.ai.v1')).byokKey === KEY);
  w.eval('closeFsModal()');
  const apiCallsBefore = seen.api.length;
  d.querySelector('#wire .row[data-id="' + ids[4] + '"]').click(); await sleep(30);
  check('drawer privacy line switches to direct-to-Anthropic copy', /straight from this browser to Anthropic/.test($('#fsBox').textContent));
  $('#fsBox [data-act="fsrun"]').click();
  await until(() => $('#fsBox .fs-score'), 5000, 'byok result');
  const hdr = seen.anthropic[seen.anthropic.length - 1] || {};
  check('BYOK goes direct to api.anthropic.com with dangerous-direct-browser-access header', hdr['anthropic-dangerous-direct-browser-access'] === 'true' && hdr['x-api-key'] === KEY && hdr['anthropic-version'] === '2023-06-01');
  check('BYOK never touches HireWire API', seen.api.length === apiCallsBefore);
  check('BYOK uses the same prompt + schema as the server', ctl.last.anthropic.body.system === require(path.join(API, 'lib', 'core')).SYSTEM_PROMPT && ctl.last.anthropic.body.output_config.format.type === 'json_schema');
  check('BYOK result cached as byok', w.eval('state.fit[' + JSON.stringify(ids[4]) + '].mode') === 'byok');
  w.eval('closeDrawer()');

  // 11) upstream busy (BYOK) → friendly error, nothing cached
  ctl.anthropic = 'busy';
  d.querySelector('#wire .row[data-id="' + ids[5] + '"]').click(); await sleep(30);
  $('#fsBox [data-act="fsrun"]').click();
  await until(() => $('#fsBox .fs-err'), 4000, 'busy error');
  check('busy upstream → "Claude is busy" message, not cached', /Claude is busy/.test($('#fsBox .fs-err').textContent) && !w.eval('state.fit[' + JSON.stringify(ids[5]) + ']'));
  ctl.anthropic = 'invalid_json';
  $('#fsBox [data-act="fsrun"]').click();
  await until(() => /unusable answer/.test(($('#fsBox .fs-err') || {}).textContent || ''), 4000, 'invalid json error');
  check('invalid model JSON rejected by client validator', true);
  ctl.anthropic = 'ok';
  w.eval('closeDrawer()');

  // 12) server per-IP free limit (5/day): remove key + pass, reset local counter, burn the remaining 2 → 3rd is 429
  w.eval('state.ai.byokKey = ""; state.ai.pass = null; state.ai.freeUsed = 0; saveAi()');
  for (const id of [ids[5], ids[6]]){
    d.querySelector('#wire .row[data-id="' + id + '"] [data-act="fsrow"]').click();
    await until(() => w.eval('!!state.fit[' + JSON.stringify(id) + ']') && !w.eval('state.fsBusy[' + JSON.stringify(id) + ']'), 5000, 'free ' + id);
    w.eval('closeDrawer()');
  }
  d.querySelector('#wire .row[data-id="' + ids[7] + '"] [data-act="fsrow"]').click();
  await until(() => $('#fsModal').classList.contains('open'), 4000, 'ip limit modal');
  check('6th free score from one network hits the server limit → paywall', /THIS NETWORK ARE USED UP/.test($('#fsModal').textContent));
  check('local free counter not charged for the refused call', w.eval('state.ai.freeUsed') === 2);

  // 13) Escape closes the modal before the drawer
  d.dispatchEvent(new w.KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
  check('Escape closes the access modal first', !$('#fsModal').classList.contains('open') && $('#drawer').classList.contains('open'));
  d.dispatchEvent(new w.KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
  check('second Escape closes the drawer', !$('#drawer').classList.contains('open'));

  // 14) forget CV
  const forget = $('#fsStatus [data-act="fscvforget"]');
  check('sidebar offers to forget the kept CV', !!forget);
  forget.click(); await sleep(20);
  check('CV removed from storage', JSON.parse(w.localStorage.getItem('hirewire.ai.v1')).cv === '');

  // 15) cancel return
  w.history.replaceState(null, '', '/?pass_cancel=1'); w.eval('fsHandleReturn()');
  check('cancel return → toast, URL cleaned', /CHECKOUT CANCELLED/.test(toasts()) && w.location.search === '');

  // 16) the page never logged errors; analytics names exist for the new actions
  check('no console errors / jsdom errors', errors.length === 0, errors.join(' || '));
  check('error bar still hidden', $('#errbar').hidden);
  check('analytics maps new actions to event names', /fsrun:'fitscore_run'/.test(html) && /fsbuy:'pass_checkout_start'/.test(html));

  console.log(results.join('\n'));
  console.log('\n' + results.filter(r => r.startsWith('PASS')).length + '/' + results.length + ' checks passed');
  await S.close();
  process.exit(process.exitCode || 0);
})().catch(async e => { console.log(results.join('\n')); console.error('TEST CRASH', e); process.exit(1); });
