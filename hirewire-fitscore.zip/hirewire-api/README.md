# hirewire-api — AI Fit Score backend for HireWire

Small Vercel project (plain Node.js serverless functions, **no framework, no npm dependencies, no database, no accounts**) behind the "AI fit score" in hirewire.fyi:

| Endpoint | What it does |
|---|---|
| `POST /api/score` | `{ cv, job:{title, company, description}, token? }` → Claude scores the CV against the posting (0–10), returns 3–6 ranked fixes + projected score. Strict JSON, validated server-side (and again in the browser). |
| `POST /api/checkout` | `{ plan:"7d" \| "30d" }` → Stripe Checkout URL (one-time payment). |
| `POST /api/claim` | `{ session_id }` (or the full return link) → verifies with Stripe that the session is paid → returns an HMAC-signed pass token `{plan, sid, exp}`. Can be claimed again with the same ID (restore on another device); expiry is fixed from the payment time. |
| `GET /api/health` | Which env vars are set (booleans only). |

Access modes (decided in the browser, enforced here):
- **Free**: 3 per browser (counted in the browser) + 5 per network per day on the server (needs Upstash; skipped if not configured).
- **Job Search Pass**: €9 / 7 days, €19 / 30 days (Stripe price IDs in env). Fair use 100 scores/pass/day (needs Upstash).
- **BYOK**: the user's own Anthropic key, called directly from the browser (`anthropic-dangerous-direct-browser-access: true`). This API is not involved.

Privacy: the CV and posting are only used to build the Claude request. They are never written to disk, a database or logs; log lines contain error codes only (a test asserts no CV/posting text reaches `console.error`). Rate-limit keys are an HMAC of the IP (never the raw IP) and expire after 2 days.

```
repo/index.html ──POST /api/score──▶ hirewire-api ──▶ api.anthropic.com/v1/messages (claude-haiku-5-5, structured JSON output)
                ──POST /api/checkout─▶            ──▶ api.stripe.com/v1/checkout/sessions
  Stripe ──redirect──▶ hirewire.fyi/?pass_session=cs_… ──POST /api/claim──▶ GET /v1/checkout/sessions/cs_… → signed pass
                (optional) Upstash Redis REST ◀── INCR counters (free per IP/day, pass per day)
BYOK: repo/index.html ──────────────────────────────▶ api.anthropic.com directly (same prompt + schema: lib/core.js)
```

`lib/core.js` (prompt, JSON schema, validator) is copied verbatim into `repo/index.html` so the BYOK path uses exactly the same prompt. After editing it run `npm run sync-core`; `npm test` fails if the copies drift.

---

## ⚠️ Before you take money: hosting plan

Vercel's **Hobby plan is for non-commercial, personal use only** (https://vercel.com/docs/plans/hobby → "the Hobby plan restricts users to non-commercial, personal use only"). Selling passes is commercial use, so for production either:
- upgrade this project's team to **Vercel Pro** (currently $20/month), or
- host the same handlers somewhere whose free tier allows commercial use (e.g. Supabase Edge Functions, Cloudflare Workers). The handlers in `lib/handlers.js` are runtime-agnostic (`ctx → {status, body}`); only `lib/http.js` is Vercel-specific. Porting is a small adapter, not done here.

Free scores + BYOK only (no payments) are fine on Hobby.

---

## Deploy, step by step

### 0. Prerequisites
- Node 20+ locally (`node -v`), a Vercel account, a Stripe account, an Anthropic API account.
- Run the tests once: `cd hirewire-api && npm test` (no keys needed; upstreams are mocked).

### 1. Anthropic key
1. https://console.anthropic.com → **API keys** → create key `hirewire-prod`.
2. **Set a monthly spend limit** (Settings → Limits). At ~$0.0014 per score, $20 covers ~14,000 scores.
3. Optional: check Settings → Data retention / privacy for your organisation, since the privacy page describes Anthropic's default API retention.

### 2. Stripe: test mode first
1. Dashboard → toggle **Test mode**.
2. **Product catalogue → Add product** "HireWire Job Search Pass – 7 days": one-off price **9.00 EUR**. Copy the price ID (`price_…`) → `STRIPE_PRICE_7D`.
3. Add product "HireWire Job Search Pass – 30 days": one-off price **19.00 EUR** → `STRIPE_PRICE_30D`.
   (CLI alternative: `stripe products create --name="HireWire Job Search Pass – 7 days"` then `stripe prices create --product=prod_… --unit-amount=900 --currency=eur`; same with 1900.)
4. Developers → API keys → copy the **test secret key** `sk_test_…` → `STRIPE_SECRET_KEY`. (A restricted key with *Checkout Sessions: write* is enough.)
5. Settings → Public details: set business name, support email, and (if you use `STRIPE_REQUIRE_TERMS=1`) your Terms URL. Settings → Emails: turn on **successful payment receipts**.
6. Decide on VAT: price incl. VAT and handle it yourself, or Stripe Tax (`STRIPE_AUTOMATIC_TAX=1`, costs extra). See open items.

### 3. Pass secret
```
node -e "console.log(require('crypto').randomBytes(32).toString('base64url'))"
```
→ `PASS_SECRET`. Changing it later invalidates every issued token (users can re-claim with their pass ID; expiry stays the same).

### 4. Optional: Upstash Redis (free tier) for the IP limit
Vercel → Storage / Marketplace → **Upstash for Redis** (or console.upstash.com → create database, region near Frankfurt). Copy the REST URL + token → `UPSTASH_REDIS_REST_URL`, `UPSTASH_REDIS_REST_TOKEN`. Without it, the per-IP free limit and the pass fair-use cap are skipped (the 3-per-browser limit still applies, but it can be reset by clearing site data). Strongly recommended before announcing free scores; `FREE_GLOBAL_DAILY_CAP` (e.g. 300) adds a hard daily ceiling on free scores.

### 5. Deploy to Vercel
**Option A, CLI** (from this folder):
```
npm i -g vercel
cd hirewire-api
vercel link            # create project "hirewire-api"
vercel env add ANTHROPIC_API_KEY production      # repeat for each variable below
vercel deploy --prod
```
**Option B, dashboard**: push `hirewire-api/` to a GitHub repo (or a subfolder of the site repo and set *Root Directory* = `hirewire-api`), then Vercel → Add New → Project → Import. Framework preset **Other**, no build command. Add the env vars under Settings → Environment Variables, then redeploy.

| Variable | Required | Value |
|---|---|---|
| `ANTHROPIC_API_KEY` | yes | `sk-ant-…` |
| `STRIPE_SECRET_KEY` | yes (for passes) | `sk_test_…` first, then `sk_live_…` |
| `STRIPE_PRICE_7D` / `STRIPE_PRICE_30D` | yes (for passes) | `price_…` (EUR 9 / EUR 19) |
| `PASS_SECRET` | yes (for passes) | 32+ random chars |
| `PUBLIC_SITE_URL` | yes | `https://hirewire.fyi` (Stripe returns to `/?pass_session={CHECKOUT_SESSION_ID}`) |
| `ANTHROPIC_MODEL` | no | default `claude-haiku-5-5` |
| `ANTHROPIC_EFFORT` | no | default `low`; empty = omit (for models without the effort parameter) |
| `UPSTASH_REDIS_REST_URL` / `_TOKEN` | no | enables IP limit + pass cap |
| `FREE_PER_IP_PER_DAY` | no | default 5 |
| `FREE_GLOBAL_DAILY_CAP` | no | default 0 (off) |
| `PASS_DAILY_CAP` | no | default 100 |
| `FREE_SCORES_ENABLED` | no | `0` = kill switch for free scores |
| `STRIPE_ALLOW_PROMO` | no | `0` hides the promo-code field |
| `STRIPE_AUTOMATIC_TAX` | no | `1` = Stripe Tax |
| `STRIPE_REQUIRE_TERMS` / `STRIPE_TERMS_MESSAGE` | no | terms checkbox + custom text at checkout |
| `ALLOWED_ORIGINS` | no | extra CORS origins (comma-separated), e.g. a staging site |

CORS always allows `https://hirewire.fyi`, `https://www.hirewire.fyi` and `http://localhost:*` / `http://127.0.0.1:*`. Requests without an allowed `Origin` get 403 (except `/api/health`).

### 6. Point the site at the API
In `repo/index.html`, section `15b · AI FIT SCORE`, set:
```js
const API_BASE = 'https://hirewire-api.vercel.app';   // ← your deployment URL (or a custom domain like https://api.hirewire.fyi)
```
Commit + push the site. Check `https://<api>/api/health`: every value should be `true` except `ip_limit` if you skipped Upstash.

### 7. Test mode end-to-end on the real site
1. Open hirewire.fyi, open a posting, paste a CV, **Score with AI** three times (free).
2. Fourth time → paywall → **Buy 30-day pass** → Stripe test card `4242 4242 4242 4242`, any future date, any CVC.
3. You return to `/?pass_session=cs_test_…` → "Pass active" modal with the pass ID; the URL is cleaned.
4. Score again (pass mode). In another browser: Passes & your key → Restore → paste the pass ID.
5. BYOK: paste your own `sk-ant-…` key → score → check in DevTools that the request goes to `api.anthropic.com` only.

### 8. Go live
Swap `STRIPE_SECRET_KEY` to `sk_live_…`, create the two **live** prices and update `STRIPE_PRICE_7D/30D`, redeploy. Do one real €9 purchase and refund it.

---

## Local development
```
npm test                       # unit + HTTP end-to-end tests with mocked Anthropic/Stripe/Upstash (37 tests)
npm run check                  # node --check on every JS file
npm i --no-save jsdom@24 && node test-ui/fitscore-ui.e2e.js   # 63-check UI test: repo/index.html in jsdom against this API
MOCK=1 npm run dev             # API on http://localhost:8787 with mocked upstreams
                               #   POST /__mock/pay {"session_id":"cs_test_mock000001"} simulates a paid checkout
set -a; . ./.env; set +a; npm run dev   # same, against real Anthropic/Stripe (test keys)
```
To try the UI locally, serve `repo/` (e.g. `npx serve repo -l 8080`) and temporarily set `API_BASE = 'http://localhost:8787'`.

## Cost per score (Claude Haiku 5.5: $0.10 / MTok input, $0.50 / MTok output, prompts < 100k tokens)
Estimated with Haiku 5.5's tokenizer (~30% more tokens than older models, ~3.1 chars/token):

| Case | Input tokens | Output tokens (JSON + thinking, effort `low`) | Cost |
|---|---|---|---|
| light (3.5k-char CV, 2.5k-char posting) | ~3,600 | ~1,100 | ~$0.0009 |
| typical (6k CV, 4k posting) | ~4,900 | ~1,800 | **~$0.0014** |
| worst case (20k + 20k chars, max_tokens 4096) | ~14,500 | 4,096 | ~$0.0035 |

So a 7-day pass used heavily (say 300 scores) costs about $0.40 in Claude; Stripe's standard EEA card fee on €9 is 1.5% + €0.25 ≈ €0.39 (premium/non-EEA cards cost more). Measure real usage: every `/api/score` response includes `usage.input_tokens/output_tokens`.

## Files
```
api/score.js  api/checkout.js  api/claim.js  api/health.js   thin Vercel entry points
lib/core.js        prompt, JSON schema, request builder, strict validator (shared with the browser)
lib/handlers.js    runtime-agnostic handlers (limits, modes, pass logic)
lib/token.js       HMAC-SHA256 pass tokens (sign/verify, timing-safe)
lib/upstream.js    fetch wrappers: Anthropic, Stripe (form-encoded REST), Upstash REST pipeline
lib/http.js        Vercel adapter: CORS allow-list, 200 KB body cap, JSON responses, no body logging
dev/mocks.js       mock Anthropic/Stripe/Upstash server     dev/local-server.js  local harness
scripts/sync-core.js   copies lib/core.js into repo/index.html
test/*.test.js     node:test suites
```

## Launch checklist
- [ ] Anthropic key created, **spend limit set**
- [ ] Stripe test products: 7-day €9.00 and 30-day €19.00 one-off EUR prices; IDs in env
- [ ] `PASS_SECRET` generated (32+ chars) and stored only in Vercel env
- [ ] `PUBLIC_SITE_URL=https://hirewire.fyi`
- [ ] Upstash connected (or a conscious decision to run without the IP limit) + `FREE_GLOBAL_DAILY_CAP` chosen
- [ ] Vercel plan allows commercial use (Pro) or handlers moved to another host
- [ ] `API_BASE` in `repo/index.html` points at the deployment; `/api/health` all green
- [ ] Test-mode purchase → claim → restore on a second browser → BYOK, all done on the real site
- [ ] Stripe receipts on; business name/support email set; Terms URL set if `STRIPE_REQUIRE_TERMS=1`
- [ ] VAT approach decided (prices incl. VAT / Stripe Tax / OSS); Impressum, terms and withdrawal-right wording for digital content checked
- [ ] privacy.html section "The optional AI fit score" reviewed and published
- [ ] Live keys + live price IDs swapped in; one real purchase + refund
