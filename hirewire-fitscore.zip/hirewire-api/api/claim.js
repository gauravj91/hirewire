'use strict';
// POST /api/claim — { session_id:'cs_...' } → { ok, token, plan, exp } (re-claimable; expiry fixed at payment time)
const { wrap } = require('../lib/http');
const { handleClaim } = require('../lib/handlers');
module.exports = wrap(handleClaim, { methods: ['POST'] });
