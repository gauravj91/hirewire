'use strict';
// POST /api/checkout — { plan:'7d'|'30d' } → { ok, url } (Stripe Checkout, one-time payment)
const { wrap } = require('../lib/http');
const { handleCheckout } = require('../lib/handlers');
module.exports = wrap(handleCheckout, { methods: ['POST'] });
