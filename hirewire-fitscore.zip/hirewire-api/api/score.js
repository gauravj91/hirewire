'use strict';
// POST /api/score — { cv, job:{ title, company, description }, token? } → { ok, mode, result, model, usage }
const { wrap } = require('../lib/http');
const { handleScore } = require('../lib/handlers');
module.exports = wrap(handleScore, { methods: ['POST'] });
