'use strict';
// GET /api/health — which env vars are configured (booleans only, never values)
const { wrap } = require('../lib/http');
const { handleHealth } = require('../lib/handlers');
module.exports = wrap(handleHealth, { methods: ['GET'], requireOrigin: false });
