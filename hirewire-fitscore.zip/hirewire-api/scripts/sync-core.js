'use strict';
// Copies lib/core.js into ../repo/index.html between the FITSCORE-CORE markers (keeps BYOK + server prompt identical).
// Usage: node scripts/sync-core.js [path/to/index.html]
const fs = require('fs');
const path = require('path');
const target = process.argv[2] || path.join(__dirname, '..', '..', 'repo', 'index.html');
const core = fs.readFileSync(path.join(__dirname, '..', 'lib', 'core.js'), 'utf8').trimEnd();
const html = fs.readFileSync(target, 'utf8');
const B = '/* FITSCORE-CORE:BEGIN — generated from hirewire-api/lib/core.js; do not edit here */';
const E = '/* FITSCORE-CORE:END */';
const i = html.indexOf(B), j = html.indexOf(E);
if (i < 0 || j < 0 || j < i) { console.error('markers not found in ' + target); process.exit(1); }
const out = html.slice(0, i + B.length) + '\n' + core + '\n' + html.slice(j);
if (out === html) { console.log('core already in sync'); process.exit(0); }
fs.writeFileSync(target, out);
console.log('synced core into ' + target);
