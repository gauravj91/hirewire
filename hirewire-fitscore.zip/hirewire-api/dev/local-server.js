'use strict';
// Local harness: serves api/* on http://localhost:8787 with the same adapter Vercel uses.
//   MOCK=1 npm run dev     → Anthropic, Stripe and Upstash are replaced by dev/mocks.js (no keys needed)
//   npm run dev            → real upstreams, reads keys from the environment (e.g. `set -a; . ./.env; set +a`)
// In mock mode, POST /__mock/pay { session_id } marks a mock Checkout Session as paid.
const http = require('http');
const { wrap } = require('../lib/http');
const H = require('../lib/handlers');
const { startMocks, payMockSession } = require('./mocks');

async function startApi(env, port) {
  const routes = {
    '/api/score': wrap(H.handleScore, { methods: ['POST'], env }),
    '/api/checkout': wrap(H.handleCheckout, { methods: ['POST'], env }),
    '/api/claim': wrap(H.handleClaim, { methods: ['POST'], env }),
    '/api/health': wrap(H.handleHealth, { methods: ['GET'], env, requireOrigin: false }),
  };
  const srv = http.createServer((req, res) => {
    const path = req.url.split('?')[0];
    const h = routes[path];
    if (h) return h(req, res);
    res.statusCode = 404; res.end('{"error":"not_found"}');
  });
  await new Promise(r => srv.listen(port || 0, '127.0.0.1', r));
  return { srv, base: 'http://127.0.0.1:' + srv.address().port, close: () => new Promise(r => srv.close(r)) };
}

async function startMockStack(overrides, apiPort) {
  const mocks = await startMocks(0);
  const env = Object.assign({
    ANTHROPIC_API_KEY: 'sk-ant-mock', ANTHROPIC_API_URL: mocks.base,
    STRIPE_SECRET_KEY: 'sk_test_mock', STRIPE_API_URL: mocks.base,
    STRIPE_PRICE_7D: 'price_7d_mock', STRIPE_PRICE_30D: 'price_30d_mock',
    PASS_SECRET: 'test-secret-test-secret-test-secret-123456',
    PUBLIC_SITE_URL: 'http://localhost:8080',
    UPSTASH_REDIS_REST_URL: mocks.base, UPSTASH_REDIS_REST_TOKEN: 'mock',
  }, overrides || {});
  const api = await startApi(env, apiPort);
  return { mocks, api, env, close: async () => { await api.close(); await mocks.close(); } };
}

module.exports = { startApi, startMockStack };

if (require.main === module) {
  (async () => {
    const port = parseInt(process.env.PORT || '8787', 10);
    if (process.env.MOCK === '1') {
      const stack = await startMockStack({}, port);
      // tiny helper endpoint to simulate a completed payment
      const orig = stack.api.srv.listeners('request')[0];
      stack.api.srv.removeAllListeners('request');
      stack.api.srv.on('request', (req, res) => {
        if (req.url === '/__mock/pay' && req.method === 'POST') {
          let raw = ''; req.on('data', c => raw += c); req.on('end', () => {
            try { const s = payMockSession(stack.mocks.ctl, JSON.parse(raw).session_id); res.end(JSON.stringify(s)); }
            catch (e) { res.statusCode = 400; res.end(JSON.stringify({ error: e.message })); }
          });
          return;
        }
        orig(req, res);
      });
      console.log('MOCK API on ' + stack.api.base + ' (upstreams mocked at ' + stack.mocks.base + ')');
    } else {
      const api = await startApi(process.env, port);
      console.log('API on ' + api.base + ' using real upstreams');
    }
  })();
}
