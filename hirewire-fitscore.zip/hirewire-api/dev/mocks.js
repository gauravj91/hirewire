'use strict';
// One local HTTP server that impersonates the three upstreams for tests and `npm run dev` with MOCK=1:
//   Anthropic  POST /v1/messages
//   Stripe     POST /v1/checkout/sessions, GET /v1/checkout/sessions/:id
//   Upstash    POST /pipeline
// Behaviour is switched through the returned `ctl` object.
const http = require('http');

const SAMPLE_RESULT = {
  score: 6.5,
  projected_score: 8,
  verdict: 'Strong TypeScript and Node match; Kubernetes ownership and team-lead scope are not shown.',
  strengths: ['5 years TypeScript/Node', 'Postgres performance work', 'AWS deployments'],
  keywords_matched: ['TypeScript', 'Node.js', 'PostgreSQL', 'AWS'],
  keywords_missing: ['Kubernetes', 'GraphQL', 'Terraform'],
  fixes: [
    { rank: 2, type: 'weak_evidence', gap_kind: 'wording', impact: 'high', title: 'Quantify the Postgres work',
      detail: 'The posting stresses performance; your bullet hides the outcome.',
      cv_evidence: 'Improved Postgres query performance for the billing service',
      suggested_rewrite: 'Cut billing-service Postgres query latency by [X%] by adding indexes and rewriting hot queries.', score_gain: 0.8 },
    { rank: 1, type: 'missing_keyword', gap_kind: 'wording', impact: 'high', title: 'Name GraphQL explicitly',
      detail: 'You built an Apollo API but never write "GraphQL", so ATS keyword matching misses it.',
      cv_evidence: 'Built the Apollo API layer for the mobile app',
      suggested_rewrite: 'Built the GraphQL (Apollo) API layer for the mobile app.', score_gain: 0.7 },
    { rank: 3, type: 'missing_evidence', gap_kind: 'real', impact: 'medium', title: 'No Kubernetes experience shown',
      detail: 'The CV shows no container orchestration. Mention adjacent ECS work honestly or address it in a cover letter.',
      cv_evidence: '', suggested_rewrite: '', score_gain: 0.5 },
    { rank: 4, type: 'seniority_scope', gap_kind: 'real', impact: 'low', title: 'Team-lead scope is a real gap',
      detail: 'The role asks for leading 4+ engineers; the CV shows mentoring one intern.', cv_evidence: 'Mentored one intern', suggested_rewrite: '', score_gain: 0 }
  ],
  caveats: ''
};

function anthropicOk(result) {
  return { id: 'msg_mock', type: 'message', role: 'assistant', model: 'claude-haiku-5-5',
    content: [{ type: 'thinking', thinking: '', signature: 'sig' }, { type: 'text', text: JSON.stringify(result || SAMPLE_RESULT) }],
    stop_reason: 'end_turn', usage: { input_tokens: 3812, output_tokens: 1140 } };
}

function startMocks(port) {
  const ctl = {
    anthropic: 'ok',           // ok | invalid_json | bad_schema | busy | error | refusal
    stripeSession: {},         // id → session object
    stripeCreate: 'ok',        // ok | error
    counters: {},
    calls: { anthropic: 0, stripeCreate: 0, stripeGet: 0, upstash: 0 },
    last: {},                  // last request headers/body shape (never the CV text itself in logs)
  };
  const srv = http.createServer((req, res) => {
    let raw = '';
    req.on('data', c => { raw += c; });
    req.on('end', () => {
      const send = (s, o) => { res.writeHead(s, { 'content-type': 'application/json' }); res.end(JSON.stringify(o)); };
      const url = req.url.split('?')[0];
      if (req.method === 'POST' && url === '/v1/messages') {
        ctl.calls.anthropic++;
        let body = {}; try { body = JSON.parse(raw); } catch (e) {}
        ctl.last.anthropic = { headers: req.headers, body };
        if (ctl.anthropic === 'busy') return send(529, { type: 'error', error: { type: 'overloaded_error', message: 'Overloaded' } });
        if (ctl.anthropic === 'error') return send(400, { type: 'error', error: { type: 'invalid_request_error', message: 'bad' } });
        if (ctl.anthropic === 'refusal') return send(200, Object.assign(anthropicOk(), { stop_reason: 'refusal', content: [] }));
        if (ctl.anthropic === 'invalid_json') return send(200, Object.assign(anthropicOk(), { content: [{ type: 'text', text: '{not json' }] }));
        if (ctl.anthropic === 'bad_schema') return send(200, anthropicOk({ score: 'high', fixes: [] }));
        return send(200, anthropicOk());
      }
      if (req.method === 'POST' && url === '/v1/checkout/sessions') {
        ctl.calls.stripeCreate++;
        const p = new URLSearchParams(raw);
        ctl.last.stripeCreate = { auth: req.headers.authorization, params: Object.fromEntries(p.entries()) };
        if (ctl.stripeCreate === 'error') return send(400, { error: { code: 'resource_missing', message: 'No such price' } });
        const id = 'cs_test_mock' + String(ctl.calls.stripeCreate).padStart(6, '0');
        ctl.stripeSession[id] = { id, object: 'checkout.session', status: 'open', payment_status: 'unpaid',
          created: Math.floor(Date.now() / 1000), metadata: { app: p.get('metadata[app]'), plan: p.get('metadata[plan]') } };
        return send(200, { id, url: 'https://checkout.stripe.com/c/pay/' + id });
      }
      const m = url.match(/^\/v1\/checkout\/sessions\/(.+)$/);
      if (req.method === 'GET' && m) {
        ctl.calls.stripeGet++;
        const s = ctl.stripeSession[decodeURIComponent(m[1])];
        if (!s) return send(404, { error: { code: 'resource_missing', message: 'No such checkout.session' } });
        return send(200, s);
      }
      if (req.method === 'POST' && url === '/pipeline') {
        ctl.calls.upstash++;
        let cmds = []; try { cmds = JSON.parse(raw); } catch (e) {}
        const out = cmds.map(c => {
          const [cmd, key] = c;
          if (cmd === 'INCR') { ctl.counters[key] = (ctl.counters[key] || 0) + 1; return { result: ctl.counters[key] }; }
          if (cmd === 'DECR') { ctl.counters[key] = (ctl.counters[key] || 0) - 1; return { result: ctl.counters[key] }; }
          if (cmd === 'EXPIRE') return { result: 1 };
          return { error: 'ERR unknown' };
        });
        return send(200, out);
      }
      send(404, { error: 'mock_not_found', url });
    });
  });
  return new Promise(resolve => srv.listen(port || 0, '127.0.0.1', () => {
    const base = 'http://127.0.0.1:' + srv.address().port;
    resolve({ srv, ctl, base, close: () => new Promise(r => srv.close(r)) });
  }));
}

// Mark a mock session as paid (what Stripe does when the customer completes Checkout).
function payMockSession(ctl, id, createdSec) {
  const s = ctl.stripeSession[id];
  if (!s) throw new Error('no such mock session ' + id);
  s.status = 'complete'; s.payment_status = 'paid';
  if (createdSec) s.created = createdSec;
  return s;
}

module.exports = { startMocks, payMockSession, SAMPLE_RESULT, anthropicOk };
