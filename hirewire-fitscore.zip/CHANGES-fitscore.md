# HireWire — AI Fit Score + Job Search Pass (index.html, privacy.html)

Backup of index.html before this work: `../index.pre-fitscore.html` (and `../work/fitscore-test/privacy.pre-fitscore.html` for privacy.html).
Backend: `../hirewire-api/` (separate Vercel project, see its README.md). Nothing committed or pushed.
`diff ../index.pre-fitscore.html index.html`: +709 / −7 lines. Line numbers below are for the edited index.html.

## What the user gets
- In every posting drawer, an **AI fit score** box: Claude rates the CV against that posting's title + description from 0 to 10. It shows:
  - a projected score "if you apply the wording fixes" (real gaps add nothing)
  - a one-line verdict, strengths, matched and missing keywords
  - **3–6 fixes ranked by impact**, each tagged *high/medium/low impact* and *wording gap* vs *real gap*, with the CV phrase it is based on, a suggested rewrite with a COPY button, and the score gain
- Rewrites may only re-word what the CV says. Numbers the CV doesn't give become `[X%]`-style placeholders, and the UI warns about them. If a fix quotes "CV evidence" that isn't in the CV word for word, it shows **"NOT FOUND WORD-FOR-WORD IN YOUR CV — CHECK IT"**.
- Results are cached per job in `localStorage` (`hirewire.fitscore.v1`, max 200 jobs). Reopening costs nothing. A "your CV or this description changed" hint appears when either one changed, and the button becomes RESCORE.
- Wire rows get an **AI FIT** hover action (opens the drawer and scores) and an **AI 7.5/10** badge once a posting is scored.
- **CV source:** the CV saved for AI scoring, else the "Paste CV text" box if it has 200+ chars, else a paste box inside the drawer. The CV is kept in this browser only if the user ticks "Keep my CV in this browser" (on by default, visible checkbox). The sidebar has "FORGET IT".
- If a source has no description, the drawer offers a box to paste the job description. ATS descriptions are fetched first when still pending.
- **Access modes** (`fsMode()`): own key → active pass → free (3 per browser) → locked (paywall).
  - **Free:** 3 per browser (counter in `hirewire.ai.v1`). The server also limits 5 per network per day when Upstash is configured. Failed calls never use up a free score.
  - **Job Search Pass:** €9 / 7 days, €19 / 30 days, one-time Stripe Checkout, no account. Return URL `/?pass_session={CHECKOUT_SESSION_ID}` → `/api/claim` → signed token stored locally; the URL is cleaned with `history.replaceState`. The modal shows the expiry and the **pass ID** with COPY. **Restore** accepts the pass ID or the full return link, on any device.
  - **BYOK:** the user's Anthropic key (stored only in this browser). The browser calls `https://api.anthropic.com/v1/messages` directly with `anthropic-dangerous-direct-browser-access: true`, using the same prompt, schema and validator as the server.
- **Paywall / access modal** (`#fsModal`): opens automatically when free scores run out (locally or the server's per-network limit) or a pass expires. It also opens from the sidebar's **PASSES & YOUR KEY**. Contents: 7-day / 30-day / own-key cards, restore field, current status, privacy line. Escape closes it before the drawer.
- Privacy copy at the point of use: before sending, the box says the CV + posting go to HireWire's scoring function → Anthropic for this one request and are not stored or logged. In BYOK mode it says they go straight to Anthropic. Both link to `/privacy.html#ai-fit-score`.

## Code map (index.html)
| Where | What |
|---|---|
| L10, L15 | meta / og description: "your CV stays in your browser unless you ask for an optional AI fit score" (the old "never leaves" claim is no longer true) |
| L373+ (CSS) | `AI FIT SCORE` block. Also: `.drawer{overflow-y:auto}`, `.d-body{min-height:200px}`, `.d-foot{position:sticky;bottom:0}`, so a tall result never squeezes the description or hides the footer buttons |
| L512 | sidebar panel `#fsPanel` (status line `#fsStatus`, `#fsManageBtn`) |
| L692 | modal container `#fsModal` |
| L1384 | `LS.ai = hirewire.ai.v1`, `LS.fit = hirewire.fitscore.v1` (so they get the IndexedDB mirror + recovery too) |
| L1398 | `state.ai / fit / fsBusy / fsErr` |
| L1476 | `loadAi()` in `loadState()` |
| L1741, L1745 | row badge + AI FIT action; L3990 click handler |
| L2459–3073 | **section 15b**: `API_BASE` (L2464, edit here), `FS_FREE_LIMIT`, `FS_PRICES` (display only), `FS_BYOK_MODEL`, the shared core (L2469–2678, generated), storage, `runFitScore`, renderers, modal, checkout/claim/restore, `bindFitScore` |
| L3104 | `#fsBox` inside the drawer, under the match/why block; L3163 re-renders it when description enrichment finishes |
| L3753 / L3759 / L4146 / L4193 | `renderFsStatus()` in `renderAll`, `bindFitScore()` in `bindEvents`, Escape order, `fsHandleReturn()` at boot |
| L4406, L4414 | analytics: event **names** only (`fitscore_run`, `fitscore_rescore`, `fitscore_row`, `fitscore_copy_rewrite`, `fitscore_access_open`, `pass_checkout_start`, `pass_restore`, `ai_key_save`, `ai_key_remove`, `ai_cv_forget`). No CV, score, job or key data |

**Shared core.** `hirewire-api/lib/core.js` holds the prompt, JSON schema, request builder and validator. It is embedded verbatim between `FITSCORE-CORE:BEGIN/END`. Edit it there, then run `cd ../hirewire-api && npm run sync-core`. `npm test` fails if the two copies differ.

**Not in backups (on purpose):** `hirewire.ai.v1` holds the API key, pass token and opt-in CV, so it stays out of "Backup everything" JSON files. The pass is restorable from its pass ID. `hirewire.fitscore.v1` (cached results) is also not in the backup.

## privacy.html
- TL;DR: "Your CV is only sent if you ask for an AI fit score" and "Paid passes go through Stripe".
- "What stays on your device": AI items (free count, pass token + ID, own key, results, CV only if ticked).
- "Who your browser talks to" table: new rows for HireWire scoring function (Vercel), Anthropic, Stripe.
- New section **`#ai-fit-score` "The optional AI fit score"**, covering:
  - the data flow in 3 steps
  - what is not stored, and what Vercel's platform logs do record
  - counters: hashed IP / pass-ID suffix, 2-day expiry
  - Anthropic's API retention, citing and linking its docs
  - BYOK key risk, payments and the pass ID, and that the AI can be wrong
- Analytics paragraph lists the new button events. "Never sent" now also covers fit scores, fix text and pass IDs.
- FAQ "Is HireWire private?" and "Is my CV sent to an AI?" rewritten, in both the JSON-LD and the visible FAQ. The CTA line is updated too.
- ⚠️ privacy.html appears to be generated by `../work/pagesbuild/pages/02_privacy.py`. **Re-running that build will overwrite these edits** unless the same text is ported into the generator. The exact edits are in `../work/fitscore-test/privacy_patch.py` (plus one sentence about Vercel request logs added afterwards).

## Tests (all run 2026-10-14)
- `node --check` on all 3 inline scripts of index.html; JSON-LD still parses (index + privacy).
- `hirewire-api`: `npm test` → **37/37**. It covers:
  - token sign/verify, tamper, expiry and malformed input
  - validator normalisation and rejection cases, structured-output schema limits
  - CORS, size limits, free / IP-limit / pass / expired / forged paths
  - Anthropic busy / error / refusal / invalid JSON / bad schema, with no allowance burned
  - checkout params, claim unpaid / paid / re-claim / foreign product / expired, the Vercel adapter
  - core-sync with index.html, and that no CV/JD text reaches the logs
- UI end-to-end, `hirewire-api/test-ui/fitscore-ui.e2e.js` → **63/63**. It runs index.html in jsdom with its `fetch` routed to the real API handlers backed by mocked Anthropic/Stripe/Upstash. Walked through:
  1. no CV → paste → free scores ×3 → paywall
  2. buy the 30-day pass → Stripe URL → paid → return → claim → URL cleaned
  3. score with the pass → restore from the return link → server-side expiry → paywall
  4. BYOK key validation → direct Anthropic call with the browser-access header, HireWire API untouched
  5. busy / invalid-JSON errors → per-network limit → Escape order → forget CV → cancel return
  - No console errors.
- Regression: the earlier product smoke test (`../work/fitscore-test/regression-product.js`, copied from `../work/jsd/test.js`) gives **identical output** on the old and new index.html (Safari/Chrome UA × feeds failing/OK).
- **Not done:** no real-browser visual check. No Chromium was available, and downloading Playwright's browser failed. The modal/drawer CSS has only been checked structurally. No call has been made to the real Anthropic or Stripe APIs (no keys here). One test run out of ~40 showed a single transient failure that did not reproduce.
